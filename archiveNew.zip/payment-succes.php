<?php
// payment-success.php - Halaman setelah konfirmasi
$order_id = $_GET['order_id'] ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfirmasi Dikirim - NYIUP.NET</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: #f8fafc;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .success-card {
            background: white;
            border-radius: 32px;
            padding: 48px 32px;
            max-width: 500px;
            width: 100%;
            text-align: center;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        
        .icon {
            width: 80px;
            height: 80px;
            background: #ecfdf5;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
            color: #059669;
            font-size: 40px;
        }
        
        h1 {
            color: #059669;
            font-size: 2rem;
            margin-bottom: 16px;
        }
        
        .message {
            background: #f1f5f9;
            border-radius: 16px;
            padding: 24px;
            margin: 24px 0;
            text-align: left;
        }
        
        .btn-home {
            background: #2563eb;
            color: white;
            text-decoration: none;
            padding: 16px 32px;
            border-radius: 12px;
            display: inline-block;
            font-weight: 600;
            margin-top: 16px;
            transition: background 0.2s;
        }
        
        .btn-home:hover {
            background: #1d4ed8;
        }
        
        .btn-wa {
            background: #25D366;
            color: white;
            text-decoration: none;
            padding: 12px 24px;
            border-radius: 12px;
            display: inline-block;
            font-weight: 600;
            margin-top: 16px;
            margin-left: 10px;
        }
        
        .note {
            color: #64748b;
            font-size: 0.9rem;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="success-card">
        <div class="icon">
            <i class="fas fa-check-circle"></i>
        </div>
        
        <h1>Konfirmasi Terkirim!</h1>
        <p>Terima kasih, pesan konfirmasi Anda sudah dikirim ke owner.</p>
        
        <div class="message">
            <p><strong>📱 WhatsApp:</strong> 082198426504</p>
            <p><strong>📧 Email:</strong> support@nyiup.net</p>
            <p style="margin-top: 12px;">Owner akan segera memproses pesanan Anda dan mengirim detailnya ke email Anda.</p>
        </div>
        
        <div>
            <a href="index.html" class="btn-home">Kembali ke Beranda</a>
            <a href="https://wa.me/6282198426504" class="btn-wa" target="_blank">
                <i class="fab fa-whatsapp"></i> Chat Owner
            </a>
        </div>
        
        <p class="note">*Proses verifikasi maksimal 5-10 menit</p>
    </div>
    
    <!-- Font Awesome -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
</body>
</html>