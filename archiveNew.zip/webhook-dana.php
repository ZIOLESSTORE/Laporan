<?php
// webhook-dana.php - Menerima notifikasi dari DANA

require_once 'config.php';

// Ambil data dari DANA
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Log untuk debugging
file_put_contents('webhook.log', date('Y-m-d H:i:s') . " - " . $input . "\n", FILE_APPEND);

// Verifikasi signature (penting untuk keamanan)
// Sesuaikan dengan dokumentasi DANA
$signature = $_SERVER['HTTP_X_DANA_SIGNATURE'] ?? '';
// TODO: Verifikasi signature dengan API Key

if (!$data) {
    http_response_code(400);
    echo 'Invalid data';
    exit;
}

$order_id = $data['orderId'] ?? $data['order_ref'] ?? '';
$status = $data['status'] ?? $data['transactionStatus'] ?? '';
$payment_id = $data['paymentId'] ?? '';

if (!$order_id || !$status) {
    http_response_code(400);
    echo 'Missing required fields';
    exit;
}

// Baca database
$transactions = getTransactions();

if (!isset($transactions[$order_id])) {
    http_response_code(404);
    echo 'Order not found';
    exit;
}

// Mapping status
$order_status = 'pending';
if ($status === 'SUCCESS' || $status === 'settlement' || $status === 'capture') {
    $order_status = 'success';
} elseif ($status === 'PENDING' || $status === 'pending') {
    $order_status = 'pending';
} elseif ($status === 'FAILED' || $status === 'deny' || $status === 'expire') {
    $order_status = 'failed';
} elseif ($status === 'REFUND') {
    $order_status = 'refunded';
}

// Update status di database
$transactions[$order_id]['status'] = $order_status;
$transactions[$order_id]['payment_id'] = $payment_id;
$transactions[$order_id]['updated_at'] = date('Y-m-d H:i:s');
$transactions[$order_id]['webhook_data'] = $data;

saveTransactions($transactions);

// Jika status success, kirim notifikasi ke owner (opsional)
if ($order_status === 'success') {
    // Kirim notifikasi WhatsApp ke owner
    $product = $transactions[$order_id]['product']['name'];
    $total = $transactions[$order_id]['total'];
    
    $message = "✅ PEMBAYARAN BERHASIL\n";
    $message .= "Order: $order_id\n";
    $message .= "Produk: $product\n";
    $message .= "Total: Rp " . number_format($total, 0, ',', '.') . "\n";
    $message .= "Silakan proses pesanan.";
    
    // TODO: Kirim ke WhatsApp owner (bisa pakai Fonnte atau layanan WA API)
    // sendWaNotification(OWNER_WA, $message);
}

// Beri response ke DANA
http_response_code(200);
echo 'OK';
?>