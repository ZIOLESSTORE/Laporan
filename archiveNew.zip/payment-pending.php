<?php
// payment-pending.php - Halaman menunggu pembayaran

require_once 'config.php';

$order_id = $_GET['order_id'] ?? '';

$transactions = getTransactions();
$transaction = $transactions[$order_id] ?? null;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menunggu Pembayaran - NYIUP.NET</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: #f8fafc;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .pending-card {
            background: white;
            border-radius: 32px;
            padding: 48px 32px;
            max-width: 500px;
            width: 100%;
            text-align: center;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        
        .icon {
            width: 80px;
            height: 80px;
            background: #fef3c7;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
            color: #d97706;
            font-size: 40px;
        }
        
        h1 {
            color: #d97706;
            font-size: 2rem;
            margin-bottom: 16px;
        }
        
        .qr-container {
            background: #f1f5f9;
            border-radius: 16px;
            padding: 24px;
            margin: 24px 0;
        }
        
        .qr-image {
            width: 200px;
            height: 200px;
            margin: 0 auto 16px;
        }
        
        .qr-image img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }
        
        .order-detail {
            text-align: left;
            margin: 20px 0;
            padding: 16px;
            background: #f8fafc;
            border-radius: 12px;
        }
        
        .btn-check {
            background: #2563eb;
            color: white;
            border: none;
            padding: 16px 32px;
            border-radius: 12px;
            font-weight: 600;
            cursor: pointer;
            margin: 10px 0;
        }
        
        .btn-wa {
            background: #25D366;
            color: white;
            text-decoration: none;
            padding: 12px 24px;
            border-radius: 12px;
            display: inline-block;
            font-weight: 600;
            margin-top: 10px;
        }
        
        .note {
            color: #64748b;
            font-size: 0.9rem;
            margin-top: 20px;
        }
        
        .expiry {
            color: #dc2626;
            font-size: 0.9rem;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="pending-card">
        <div class="icon">
            <i class="fas fa-clock"></i>
        </div>
        
        <h1>Menunggu Pembayaran</h1>
        <p>Silakan selesaikan pembayaran Anda</p>
        
        <div class="qr-container">
            <div class="qr-image">
                <?php if ($transaction && isset($transaction['qr_code'])): ?>
                    <img src="<?php echo htmlspecialchars($transaction['qr_code']); ?>" alt="QRIS">
                <?php else: ?>
                    <img src="assets/images/qris-dana.png" alt="QRIS DANA">
                <?php endif; ?>
            </div>
            <p><strong>Scan QR di atas untuk membayar</strong></p>
        </div>
        
        <div class="order-detail">
            <p><strong>Order ID:</strong> <?php echo htmlspecialchars($order_id ?: '-'); ?></p>
            <p><strong>Total:</strong> Rp <?php echo number_format($transaction['total'] ?? 0, 0, ',', '.'); ?></p>
            <p><strong>Metode:</strong> QRIS (DANA/OVO/GoPay/ShopeePay)</p>
        </div>
        
        <button class="btn-check" onclick="checkPayment()">
            <i class="fas fa-sync-alt"></i> Cek Status Pembayaran
        </button>
        
        <div>
            <a href="https://wa.me/<?php echo OWNER_WA; ?>?text=Halo%20admin%2C%20saya%20sudah%20bayar%20order%20<?php echo $order_id; ?>%20via%20QRIS" class="btn-wa" target="_blank">
                <i class="fab fa-whatsapp"></i> Konfirmasi via WA
            </a>
        </div>
        
        <p class="expiry">*QRIS berlaku 15 menit</p>
        <p class="note">Setelah bayar, halaman ini akan otomatis ter-update</p>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
    <script>
        function checkPayment() {
            // Cek status pembayaran via AJAX
            fetch('check-payment-status.php?order_id=<?php echo $order_id; ?>')
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        window.location.href = 'payment-success.php?order_id=<?php echo $order_id; ?>';
                    } else if (data.status === 'failed') {
                        alert('Pembayaran gagal. Silakan coba lagi.');
                    } else {
                        alert('Pembayaran masih pending. Silakan tunggu.');
                    }
                });
        }
        
        // Auto check setiap 10 detik
        setInterval(checkPayment, 10000);
    </script>
</body>
</html>