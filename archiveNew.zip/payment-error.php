<?php
// payment-error.php - Halaman error pembayaran

$error = $_GET['error'] ?? 'Terjadi kesalahan dalam proses pembayaran';
$order_id = $_GET['order_id'] ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran Gagal - NYIUP.NET</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: #f8fafc;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .error-card {
            background: white;
            border-radius: 32px;
            padding: 48px 32px;
            max-width: 500px;
            width: 100%;
            text-align: center;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        
        .icon {
            width: 80px;
            height: 80px;
            background: #fee2e2;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
            color: #dc2626;
            font-size: 40px;
        }
        
        h1 {
            color: #dc2626;
            font-size: 2rem;
            margin-bottom: 16px;
        }
        
        .error-message {
            background: #fef2f2;
            border: 1px solid #fecaca;
            border-radius: 12px;
            padding: 16px;
            margin: 24px 0;
            color: #991b1b;
        }
        
        .btn-group {
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .btn-primary {
            background: #2563eb;
            color: white;
            text-decoration: none;
            padding: 14px 28px;
            border-radius: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .btn-secondary {
            background: #64748b;
            color: white;
            text-decoration: none;
            padding: 14px 28px;
            border-radius: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .btn-wa {
            background: #25D366;
            color: white;
            text-decoration: none;
            padding: 14px 28px;
            border-radius: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .note {
            color: #64748b;
            font-size: 0.9rem;
            margin-top: 24px;
        }
    </style>
</head>
<body>
    <div class="error-card">
        <div class="icon">
            <i class="fas fa-exclamation-triangle"></i>
        </div>
        
        <h1>Pembayaran Gagal</h1>
        
        <div class="error-message">
            <?php echo htmlspecialchars($error); ?>
            <?php if ($order_id): ?>
                <p style="margin-top: 10px; font-size: 0.9rem;">Order ID: <?php echo $order_id; ?></p>
            <?php endif; ?>
        </div>
        
        <div class="btn-group">
            <a href="index.html" class="btn-primary">Kembali ke Beranda</a>
            <a href="javascript:history.back()" class="btn-secondary">Coba Lagi</a>
        </div>
        
        <div style="margin-top: 16px;">
            <a href="https://wa.me/<?php echo OWNER_WA; ?>?text=Halo%20admin%2C%20saya%20mengalami%20kendala%20pembayaran%20<?php echo $order_id; ?>" class="btn-wa" target="_blank">
                <i class="fab fa-whatsapp"></i> Hubungi Admin
            </a>
        </div>
        
        <p class="note">Jika masalah berlanjut, silakan hubungi owner via WhatsApp</p>
    </div>
    
    <!-- Font Awesome -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
</body>
</html>