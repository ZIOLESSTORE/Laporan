=== TOKO VPS ONLINE - NYIUP.NET ===
Sistem pembayaran via QRIS + Konfirmasi WhatsApp

==========================================
 CARA INSTALASI
==========================================

1. Upload semua file ke hosting/VPS Anda
2. Pastikan struktur folder seperti ini:

   public_html/
   ├── index.html
   ├── payment-success.php
   ├── assets/
   │   ├── css/
   │   │   └── style.css
   │   ├── js/
   │   │   └── script.js
   │   └── images/
   │       └── qris-dana.png  ← GANTI DENGAN QRIS ANDA
   └── README.txt

3. GANTI QRIS:
   - Ambil QRIS dari aplikasi DANA Bisnis Anda
   - Simpan di assets/images/qris-dana.png
   - (Jika pakai QRIS lain, ganti nama filenya)

4. GANTI NOMOR WHATSAPP (opsional):
   - Buka file index.html
   - Cari semua "6282198426504"
   - Ganti dengan nomor WA Anda (pakai format 62)

5. GANTI EMAIL (opsional):
   - Buka file index.html
   - Cari "support@nyiup.net"
   - Ganti dengan email Anda

==========================================
 CARA MENGGUNAKAN
==========================================

1. Buka website: https://domain-anda.com/index.html
2. Pelanggan pilih produk → Login → Checkout
3. Pelanggan scan QRIS DANA Anda
4. Pelanggan bayar sesuai total
5. Pelanggan klik tombol "Saya Sudah Bayar"
6. Otomatis terbuka WhatsApp dengan pesan konfirmasi
7. Pelanggan kirim pesan
8. Anda cek di aplikasi DANA apakah uang masuk
9. Jika sudah masuk, proses pesanan dan kirim ke email pelanggan

==========================================
 FILE YANG TIDAK DIGUNAKAN
==========================================

File-file berikut TIDAK PERLU ADA (bisa dihapus):
- checkout-qris.php
- webhook-dana.php
- config.php
- transactions.json
- payment-pending.php
- payment-error.php
- folder includes/

==========================================
 BUTUH BANTUAN?
==========================================

WhatsApp: 082198426504
Email: support@nyiup.net

Selamat berjualan! 🚀