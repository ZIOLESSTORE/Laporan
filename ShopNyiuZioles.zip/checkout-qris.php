<?php
// checkout-qris.php - Generate QRIS DANA

require_once 'config.php';

header('Content-Type: application/json');

// Cek method request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// Ambil data dari request
$input = json_decode(file_get_contents('php://input'), true);
$product = $input['product'] ?? null;
$quantity = $input['quantity'] ?? 1;
$total = $input['total'] ?? 0;
$email = $input['email'] ?? 'guest@example.com';

if (!$product || !$total) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Data tidak lengkap']);
    exit;
}

// Generate Order ID
$order_id = generateOrderId();

// ===== MEMANGGIL API DANA =====
// Catatan: Ini adalah contoh struktur. Sesuaikan dengan dokumentasi API DANA yang sebenarnya
$dana_data = [
    'merchantId' => DANA_MERCHANT_ID,
    'orderId' => $order_id,
    'amount' => $total,
    'currency' => 'IDR',
    'description' => $product['name'] . ' x ' . $quantity,
    'customer' => [
        'email' => $email
    ],
    'callbackUrl' => BASE_URL . '/webhook-dana.php',
    'returnUrl' => BASE_URL . '/payment-success.php?order_id=' . $order_id
];

// Kirim request ke DANA API
$ch = curl_init(DANA_API_URL . '/payments/qris');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($dana_data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . DANA_API_KEY
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200) {
    $result = json_decode($response, true);
    
    // Simpan transaksi ke database
    $transactions = getTransactions();
    $transactions[$order_id] = [
        'order_id' => $order_id,
        'product' => $product,
        'quantity' => $quantity,
        'total' => $total,
        'status' => 'pending',
        'payment_method' => 'qris',
        'customer_email' => $email,
        'payment_id' => $result['paymentId'] ?? '',
        'qr_code' => $result['qrCode'] ?? '',
        'created_at' => date('Y-m-d H:i:s')
    ];
    saveTransactions($transactions);
    
    // Kirim response ke frontend
    echo json_encode([
        'success' => true,
        'order_id' => $order_id,
        'qr_code' => $result['qrCode'] ?? '',
        'qr_url' => $result['qrImageUrl'] ?? '',
        'expiry' => $result['expiryTime'] ?? ''
    ]);
} else {
    // Log error
    file_put_contents('dana_error.log', date('Y-m-d H:i:s') . " - " . $response . "\n", FILE_APPEND);
    
    // Fallback ke QRIS statis (manual)
    echo json_encode([
        'success' => true,
        'order_id' => $order_id,
        'qr_code' => 'assets/images/qris-dana.png', // QR statis Anda
        'qr_url' => 'payment-pending.php?order_id=' . $order_id,
        'note' => 'Gunakan QRIS statis (manual)'
    ]);
}
?>