<?php
// config.php - Konfigurasi Database dan API

// ===== KONFIGURASI DATABASE =====
// Menggunakan file JSON sederhana
define('TRANSACTION_FILE', __DIR__ . '/transactions.json');

// Inisialisasi file JSON jika belum ada
if (!file_exists(TRANSACTION_FILE)) {
    file_put_contents(TRANSACTION_FILE, json_encode([]));
}

// ===== KONFIGURASI DANA API =====
// Untuk integrasi dengan DANA Bisnis (isi sesuai akun Anda)
define('DANA_MERCHANT_ID', 'YOUR_MERCHANT_ID');      // Dari DANA Bisnis
define('DANA_API_KEY', 'YOUR_API_KEY');              // Dari DANA Bisnis
define('DANA_API_URL', 'https://api.dana.id/v1');    // Production URL
// define('DANA_API_URL', 'https://sandbox.dana.id/v1'); // Untuk testing

// ===== KONFIGURASI WEBSITE =====
define('BASE_URL', 'https://domain-anda.com');       // Ganti dengan domain Anda

// ===== KONFIGURASI WHATSAPP OWNER =====
define('OWNER_WA', '6282198426504');

// Fungsi helper untuk membaca transactions
function getTransactions() {
    return json_decode(file_get_contents(TRANSACTION_FILE), true);
}

// Fungsi helper untuk menyimpan transactions
function saveTransactions($data) {
    file_put_contents(TRANSACTION_FILE, json_encode($data, JSON_PRETTY_PRINT));
}

// Fungsi untuk generate Order ID
function generateOrderId() {
    return 'ORDER-' . date('Ymd') . '-' . time() . '-' . rand(100, 999);
}
?>