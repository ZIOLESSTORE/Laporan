<?php
// includes/functions.php - Fungsi-fungsi helper

function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function generateOrderId() {
    return 'INV-' . date('Ymd') . '-' . strtoupper(uniqid());
}

function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

function sendWaNotification($phone, $message) {
    // Implementasi kirim notifikasi WhatsApp
    // Bisa pakai layanan seperti Fonnte, WABlas, dll
    $api_key = 'YOUR_WA_API_KEY';
    $url = "https://api.fonnte.com/send";
    
    $data = [
        'target' => $phone,
        'message' => $message,
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: ' . $api_key
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return $response;
}

function logActivity($message) {
    $log = date('Y-m-d H:i:s') . " - " . $message . PHP_EOL;
    file_put_contents(__DIR__ . '/../logs/activity.log', $log, FILE_APPEND);
}

function getPaymentStatus($order_id) {
    $transactions = getTransactions();
    return $transactions[$order_id]['status'] ?? 'not_found';
}

function updatePaymentStatus($order_id, $status) {
    $transactions = getTransactions();
    if (isset($transactions[$order_id])) {
        $transactions[$order_id]['status'] = $status;
        $transactions[$order_id]['updated_at'] = date('Y-m-d H:i:s');
        saveTransactions($transactions);
        return true;
    }
    return false;
}
?>