// ========== DATA PRODUK ==========
const productData = {
    vps: [
        { name: "RAM 2 CORE 1", price: 10000, spek: "2GB RAM · 1 Core", note: "15-30 hari 99.99%" },
        { name: "RAM 4 CORE 2", price: 18000, spek: "4GB RAM · 2 Core", note: "15-30 hari" },
        { name: "RAM 8 CORE 2", price: 25000, spek: "8GB RAM · 2 Core", note: "15-30 hari" },
        { name: "RAM 8 CORE 4", price: 30000, spek: "8GB RAM · 4 Core", note: "15-30 hari" },
        { name: "RAM 16 CORE 4", price: 35000, spek: "16GB · 4 Core", note: "15-30 hari" },
        { name: "RAM 16 CORE 8", price: 38000, spek: "16GB · 8 Core", note: "15-30 hari" },
        { name: "RAM 32 CORE 8/16", price: 50000, spek: "32GB · 8/16 Core", note: "15-30 hari" },
        { name: "RAM 64 CORE 16", price: 85000, spek: "64GB · 16 Core", note: "15-30 hari" },
        { name: "RAM 128 CORE 32", price: 125000, spek: "128GB · 32 Core", note: "15-30 hari" },
        { name: "RAM 198 CORE 64", price: 300000, spek: "198GB · 64 Core", note: "15-30 hari" }
    ],
    do: [
        { name: "DROP 3 2 BULAN", price: 100000, spek: "3 drop · 2 bulan", note: "99.99%" },
        { name: "DROP 10 2 BULAN", price: 135000, spek: "10 drop · 2 bulan", note: "99.99%" },
        { name: "DROP 30 2BLN-1TH", price: 250000, spek: "30 drop · 2 bulan - 1 tahun", note: "awet" }
    ],
    whm: [
        { name: "WHM License", price: 70000, spek: "70K tergantung", note: "harga dasar" }
    ],
    cpanel: [
        { name: "cPanel License", price: 15000, spek: "15K tergantung", note: "harga dasar" }
    ]
};

// ========== STATE ==========
let currentUser = null;
let cart = [];

// ========== DOM ELEMENTS ==========
const pages = document.querySelectorAll('.page');
const navLinks = document.querySelectorAll('[data-page]');
const avatarBtn = document.getElementById('avatarBtn');
const dropdown = document.getElementById('dropdown');
const showLoginBtn = document.getElementById('showLoginBtn');
const contactOwner = document.getElementById('contactOwner');
const logoutBtn = document.getElementById('logoutBtn');
const authModal = document.getElementById('authModal');
const closeModal = document.querySelector('.close-modal');
const authTitle = document.getElementById('authTitle');
const switchAuth = document.getElementById('switchToRegister');
const emailInput = document.getElementById('emailInput');
const passInput = document.getElementById('passInput');
const authSubmit = document.getElementById('authSubmit');
const googleLogin = document.getElementById('googleLogin');
const fbLogin = document.getElementById('fbLogin');
const vpsSlider = document.getElementById('vpsSlider');
const doSlider = document.getElementById('doSlider');
const cpanelSlider = document.getElementById('cpanelSlider');
const listGrid = document.getElementById('listProductGrid');
const catBtns = document.querySelectorAll('.cat-btn');
const checkoutPage = document.getElementById('checkoutPage');
const checkoutItems = document.getElementById('checkoutItems');
const confirmPayment = document.getElementById('confirmPayment');
const displayTotal = document.getElementById('displayTotal');
const displayNominal = document.getElementById('displayNominal');

// ========== HELPER FUNCTIONS ==========
function formatRupiah(amount) {
    return 'Rp ' + amount.toLocaleString('id-ID');
}

function showPage(pageId) {
    pages.forEach(p => p.classList.remove('active'));
    document.getElementById(pageId).classList.add('active');
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.dataset.page === pageId.replace('Page', '')) {
            link.classList.add('active');
        }
    });
}

// ========== RENDER PRODUCT SLIDER ==========
function renderSliders() {
    // VPS Slider
    vpsSlider.innerHTML = '';
    productData.vps.forEach(p => {
        vpsSlider.appendChild(createProductCard(p, 'vps'));
    });
    
    // DO Slider
    doSlider.innerHTML = '';
    productData.do.forEach(p => {
        doSlider.appendChild(createProductCard(p, 'do'));
    });
    
    // WHM/cPanel Slider
    cpanelSlider.innerHTML = '';
    [...productData.whm, ...productData.cpanel].forEach(p => {
        cpanelSlider.appendChild(createProductCard(p, 'whm'));
    });
}

function createProductCard(product, category) {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
        <div class="price">${formatRupiah(product.price)}<small>/unit</small></div>
        <div class="name">${product.name}</div>
        <div class="spec">${product.spek}</div>
        <div class="note">${product.note}</div>
        <button class="btn-order" data-category="${category}" data-product='${JSON.stringify(product)}'>
            Pilih
        </button>
    `;
    
    card.querySelector('.btn-order').addEventListener('click', (e) => {
        e.stopPropagation();
        if (!currentUser) {
            authModal.classList.add('show');
            return;
        }
        
        const productData = JSON.parse(e.target.dataset.product);
        openCheckout(productData, category);
    });
    
    return card;
}

// ========== RENDER PRODUCT GRID ==========
function renderProductGrid(category = 'vps') {
    const products = productData[category] || [];
    listGrid.innerHTML = '';
    
    products.forEach(p => {
        const card = document.createElement('div');
        card.className = 'grid-card';
        card.innerHTML = `
            <div class="name" style="font-size: 1.3rem;">${p.name}</div>
            <div class="spec">${p.spek}</div>
            <div class="note">${p.note}</div>
            <div class="price" style="font-size: 1.8rem; margin: 16px 0;">${formatRupiah(p.price)}</div>
            <div class="buy-action">
                <input type="number" min="1" value="1" class="qty-input" id="qty-${p.name.replace(/\s/g,'')}">
                <button class="btn-buy" data-category="${category}" data-product='${JSON.stringify(p)}'>
                    Beli
                </button>
            </div>
        `;
        
        card.querySelector('.btn-buy').addEventListener('click', (e) => {
            if (!currentUser) {
                authModal.classList.add('show');
                return;
            }
            
            const productData = JSON.parse(e.target.dataset.product);
            const qty = document.getElementById(`qty-${p.name.replace(/\s/g,'')}`).value;
            openCheckout(productData, category, parseInt(qty));
        });
        
        listGrid.appendChild(card);
    });
}

// ========== CHECKOUT FUNCTIONS ==========
function openCheckout(product, category, quantity = 1) {
    cart = [{ product, category, quantity }];
    showCheckout();
}

function showCheckout() {
    if (!currentUser) {
        authModal.classList.add('show');
        return;
    }
    
    showPage('checkoutPage');
    
    let html = '';
    let total = 0;
    
    cart.forEach(item => {
        const subtotal = item.product.price * item.quantity;
        total += subtotal;
        html += `
            <div class="payment-item">
                <div>
                    <strong>${item.product.name}</strong>
                    <br>
                    <small>${formatRupiah(item.product.price)} x ${item.quantity}</small>
                </div>
                <div>${formatRupiah(subtotal)}</div>
            </div>
        `;
    });
    
    html += `
        <div class="payment-item total">
            <div><strong>TOTAL</strong></div>
            <div><strong>${formatRupiah(total)}</strong></div>
        </div>
    `;
    
    checkoutItems.innerHTML = html;
    
    // Update total yang ditampilkan di panel pembayaran
    displayTotal.innerText = formatRupiah(total);
    displayNominal.innerText = total.toLocaleString('id-ID');
    
    // Simpan total untuk keperluan lain
    checkoutPage.dataset.total = total;
}

// ========== KONFIRMASI PEMBAYARAN VIA WA ==========
confirmPayment.addEventListener('click', function() {
    if (!currentUser) {
        authModal.classList.add('show');
        return;
    }
    
    if (cart.length === 0) return;
    
    const item = cart[0];
    const total = parseInt(checkoutPage.dataset.total);
    
    // Format pesan WhatsApp
    const pesan = `Halo admin NYIUP.NET, saya sudah melakukan pembayaran via QRIS DANA.

*DETAIL PESANAN*
Produk: ${item.product.name}
Harga: ${formatRupiah(item.product.price)}
Jumlah: ${item.quantity} unit
Total: ${formatRupiah(total)}

*DATA PEMBELI*
Email: ${currentUser.email}
Nama: ${currentUser.name || currentUser.email.split('@')[0]}

*KONFIRMASI*
Saya sudah transfer sesuai total di atas. Mohon segera diproses dan dikirim detail VPS/akunnya ke email saya.

Terima kasih.`;
    
    // Encode pesan untuk URL
    const encodedPesan = encodeURIComponent(pesan);
    
    // Buka WhatsApp
    window.open(`https://wa.me/6282198426504?text=${encodedPesan}`, '_blank');
    
    // Tampilkan notifikasi
    alert('Pesan konfirmasi telah dikirim ke WhatsApp owner. Mohon tunggu konfirmasi lanjutan.');
});

// ========== NAVIGATION ==========
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const pageId = link.dataset.page + 'Page';
        showPage(pageId);
        
        if (link.dataset.page === 'list') {
            renderProductGrid('vps');
        }
    });
});

catBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        catBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        renderProductGrid(btn.dataset.cat);
    });
});

// ========== USER DROPDOWN ==========
avatarBtn.addEventListener('click', () => {
    dropdown.classList.toggle('show');
});

document.addEventListener('click', (e) => {
    if (!avatarBtn.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.classList.remove('show');
    }
});

showLoginBtn.addEventListener('click', () => {
    dropdown.classList.remove('show');
    authModal.classList.add('show');
});

contactOwner.addEventListener('click', () => {
    window.open('https://wa.me/6282198426504', '_blank');
});

// ========== LOGIN MODAL ==========
closeModal.addEventListener('click', () => {
    authModal.classList.remove('show');
});

window.addEventListener('click', (e) => {
    if (e.target === authModal) {
        authModal.classList.remove('show');
    }
});

authSubmit.addEventListener('click', (e) => {
    e.preventDefault();
    const email = emailInput.value.trim();
    const pass = passInput.value.trim();
    
    if (email && pass) {
        currentUser = {
            email: email,
            name: email.split('@')[0]
        };
        
        authModal.classList.remove('show');
        avatarBtn.innerHTML = `<span>${email[0].toUpperCase()}</span>`;
        showLoginBtn.style.display = 'none';
        logoutBtn.style.display = 'flex';
        
        // Reset form
        emailInput.value = '';
        passInput.value = '';
        
        alert(`Selamat datang, ${email.split('@')[0]}!`);
    } else {
        alert('Email dan password wajib diisi!');
    }
});

googleLogin.addEventListener('click', () => {
    currentUser = {
        email: 'user@gmail.com',
        name: 'User Google'
    };
    
    authModal.classList.remove('show');
    avatarBtn.innerHTML = '<span>G</span>';
    showLoginBtn.style.display = 'none';
    logoutBtn.style.display = 'flex';
});

fbLogin.addEventListener('click', () => {
    currentUser = {
        email: 'user@facebook.com',
        name: 'User Facebook'
    };
    
    authModal.classList.remove('show');
    avatarBtn.innerHTML = '<span>F</span>';
    showLoginBtn.style.display = 'none';
    logoutBtn.style.display = 'flex';
});

logoutBtn.addEventListener('click', () => {
    currentUser = null;
    avatarBtn.innerHTML = '<i class="fas fa-user"></i>';
    showLoginBtn.style.display = 'flex';
    logoutBtn.style.display = 'none';
    dropdown.classList.remove('show');
});

switchAuth.addEventListener('click', () => {
    if (authTitle.textContent === 'Masuk / Daftar') {
        authTitle.textContent = 'Daftar Akun Baru';
        authSubmit.textContent = 'Daftar';
        switchAuth.textContent = 'Sudah punya akun? Masuk';
    } else {
        authTitle.textContent = 'Masuk / Daftar';
        authSubmit.textContent = 'Lanjut';
        switchAuth.textContent = 'Belum punya akun? Daftar';
    }
});

// ========== INITIALIZATION ==========
renderSliders();
renderProductGrid('vps');